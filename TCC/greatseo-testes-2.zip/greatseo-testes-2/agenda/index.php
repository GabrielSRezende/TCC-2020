<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Event Calendar With Bootstrap 4 And Local Storage Example</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/4.3.1/materia/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <h1 style="margin:150px auto 30px auto; text-align:center">Event Calendar With Bootstrap 4 And Local Storage Example</h1>
    <div id="app"></div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>

</html>

<script type="text/javascript">
	$(".showEvent").click(function() {
	var x =$(".event-date").val();
	
});
</script>