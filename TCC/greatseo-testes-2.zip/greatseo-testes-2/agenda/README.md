# JS Event Calendar
A responsive calendar made with Javascript, Jquery and Bootstrap.
**Calendar is in Vanila JS, using Jquery in events saved me some keystrokes :).**
Events are stored in your browser's localstorage.

![JavaScript Calendar](https://github.com/surajverma/calendar/blob/master/calendar.png?raw=true)
